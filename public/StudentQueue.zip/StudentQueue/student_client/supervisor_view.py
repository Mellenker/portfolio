from PyQt6.QtGui import QStandardItemModel, QStandardItem

class SupervisorView:
    def __init__(self, list_view):
        self.__list_view = list_view

        self.__list_view_model = QStandardItemModel()
        self.__list_view.setModel(self.__list_view_model)

    def update_view(self, supervisors):        
        # Clear the previous items
        self.__list_view_model.clear()

        # Add new items
        for supervisor in supervisors:
            name = supervisor['name']
            status = supervisor['status']
            client = supervisor.get('client')

            item_text = f"{name}\n• {status.capitalize()}"
            
            # If the supervisor is helping a client, add that information
            if client:
                item_text += f"\n• Helping: \"{client['name']}\""

            # Add a blank line to separate supervisors
            item_text += "\n"

            item = QStandardItem(item_text)
            item.setText(item_text)
            self.__list_view_model.appendRow(item)
