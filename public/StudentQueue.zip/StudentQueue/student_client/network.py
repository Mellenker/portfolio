import zmq
import json
import threading
import time

from PyQt6.QtCore import QObject, pyqtSignal

class Network(QObject):
    user_signal = pyqtSignal(bool, str)
    queue_signal = pyqtSignal(list)
    supervisors_signal = pyqtSignal(list)

    def __init__(self, user, server, broad_port, req_port):
        super().__init__()

        self.__user = user

        # Delay for fetching data in seconds
        self.__fetch_delay = 0.5

        # Server IP
        ip = server
        self.__broad_ip = ip + ":" + broad_port
        self.__req_ip = ip + ":" + req_port

        # Broadcast sockets
        self.__student_socket = None
        self.__supervisor_socket = None
        self.__user_socket = None

        # Request/Reply socket
        self.__req_socket = None

        # Threads
        self.__heartbeat_thread = None
        self.__queue_thread = None
        self.__supervisor_thread = None
        self.__user_message_thread = None

        self.__setup_connection()

    # Sets up the connection to the server
    def __setup_connection(self):
        context = zmq.Context()

        ### Broadcast sockets ###

        # Set up a socket for the student queue
        self.__student_socket = context.socket(zmq.SUB)
        self.__student_socket.setsockopt_string(zmq.SUBSCRIBE, "queue")
        self.__student_socket.connect(self.__broad_ip)
        
        # Set up a socket for the supervisor list
        self.__supervisor_socket = context.socket(zmq.SUB)
        self.__supervisor_socket.setsockopt_string(zmq.SUBSCRIBE, "supervisors")
        self.__supervisor_socket.connect(self.__broad_ip)

        # Set up a socket for the user messages
        self.__user_socket = context.socket(zmq.SUB)
        self.__user_socket.connect(self.__broad_ip)

        ### Request/Reply socket ###

        # Set up a req socket
        self.__req_socket = context.socket(zmq.REQ)
        self.__req_socket.connect(self.__req_ip)

    # Starts threads
    def start_threads(self):
        # Start the monitoring thread
        monitor_thread = threading.Thread(target=self.__monitor_connection)
        monitor_thread.daemon = True
        monitor_thread.start()

        # Start the queue thread
        self.__queue_thread = threading.Thread(target=self.__fetch_queue)
        self.__queue_thread.daemon = True
        self.__queue_thread.start()

        # Start the supervisor thread
        self.__supervisor_thread = threading.Thread(target=self.__fetch_supervisors)
        self.__supervisor_thread.daemon = True
        self.__supervisor_thread.start()

        # Start the user message thread
        self.__user_message_thread = threading.Thread(target=self.__fetch_users_messages)
        self.__user_message_thread.daemon = True
        self.__user_message_thread.start()

    ######################
    # Broadcast messages #
    ######################

    # Fetches the queue from the server
    def __fetch_queue(self):
        while True:
            try:
                # Flush old messages because "zmq.CONFLATE" does not work for some reason
                try:
                    while True:
                        # Keep receiving until the last message
                        topic, msg = self.__student_socket.recv_multipart(zmq.NOBLOCK)
                except zmq.Again:
                    # No more messages, process the last message
                    parsed_msg = json.loads(msg)
                    self.queue_signal.emit(parsed_msg)

            except:
                pass
            finally:
                time.sleep(self.__fetch_delay)
    
    # Fetches the supervisors from the server
    def __fetch_supervisors(self):
        while True:
            try:
                # Flush old messages because "zmq.CONFLATE" does not work for some reason
                try:
                    while True:
                        # Keep receiving until the last message
                        topic, msg = self.__supervisor_socket.recv_multipart(zmq.NOBLOCK)
                except zmq.Again:
                    # No more messages, process the last message
                    parsed_msg = json.loads(msg)    

                    self.supervisors_signal.emit(parsed_msg)

            except:
                pass
            finally:
                time.sleep(self.__fetch_delay)
    
    # Fetches user messages from the server
    def __fetch_users_messages(self):
        while True:
            try:
                # Get the username
                username = self.__user.get_username()

                if username == "":
                    time.sleep(self.__fetch_delay)
                    continue

                old_username = self.__user.get_old_username()

                # Subscribe to the new username and unsubscribe from the old one
                if username != old_username:
                    if old_username == "":
                        self.__user_socket.setsockopt_string(zmq.SUBSCRIBE, username)
                    else:
                        self.__user_socket.setsockopt_string(zmq.UNSUBSCRIBE, old_username)
                        self.__user_socket.setsockopt_string(zmq.SUBSCRIBE, username)

                    self.__user.set_old_username(username)

                try:
                    topic, msg = self.__user_socket.recv_multipart(zmq.NOBLOCK)
                    
                    # Getting here means user is getting help

                    parsed_msg = json.loads(msg)

                    message = parsed_msg.get("message", "")
                    self.user_signal.emit(True, message)

                    self.__user.set_in_queue(False)
                except:
                    # User is not getting help
                    pass
            
            except:
                pass
            finally:
                time.sleep(self.__fetch_delay)
    
    ##########################
    # Request/Reply messages #
    ##########################

    # Enter the queue
    def enter_queue(self):
        self.__user.set_in_queue(False)

        if self.__heartbeat_thread != None:
            self.__heartbeat_thread.join()

        request = {
            "clientId": self.__user.get_client_id(),
            "name": self.__user.get_username(),
            "enterQueue": True
        }

        try:
            self.__req_socket.send_json(request)
            msg = self.__req_socket.recv_json()
        except:
            return

        # Check that the server accepted the request
        name = msg.get("name", "")

        if name == "":
            return
        
        self.__user.set_ticket(msg.get("ticket", ""))
        self.__user.set_in_queue(True)

        self.__heartbeat_thread = threading.Thread(target=self.__send_heartbeat)
        self.__heartbeat_thread.daemon = True
        self.__heartbeat_thread.start()

    # Sends a heartbeat to the server
    def __send_heartbeat(self):
        request = { "clientId": self.__user.get_client_id() }

        time.sleep(0.5)

        while self.__user.get_in_queue():
            try:
                self.__req_socket.send_json(request)

                msg = self.__req_socket.recv_json()
            except:
                pass
            finally:
                time.sleep(0.5)
    
    # Tries to reconnect to the server
    def __reconnect(self):
        request = {
            "clientId": self.__user.get_client_id(),
            "name": self.__user.get_username(),
            "ticket": self.__user.get_ticket(),
            "reconnect": True
        }

        try:
            self.__req_socket.send_json(request)
            msg = self.__req_socket.recv_json()
        except:
            return

    ##############
    # Monitoring #
    ##############

    # Monitors the connection to the server
    def __monitor_connection(self):
        # Get the monitoring socket
        monitor_socket = self.__req_socket.get_monitor_socket()

        while True:
            try:
                event = monitor_socket.recv_multipart()

                # The first part of the message is the event type (as an integer)
                event_type = int.from_bytes(event[0], byteorder="little")

                # Decode bitwise event type
                if event_type & zmq.EVENT_DISCONNECTED:
                    # Reconnect if in queue
                    if self.__user.get_in_queue():
                        self.__reconnect()

            except:
                continue
