import uuid
import hashlib
import time

class User:
    def __init__(self):
        self.__client_id = self.__generate_client_id()

        self.__username = ""
        self.__old_username = ""
        self.__in_queue = False
        self.__ticket = None

    # Generates a unique client ID based on the MAC address
    def __generate_client_id(self):
        # Get the MAC address
        mac = str(uuid.getnode())

        # Get the current time in nanoseconds
        current_time = str(time.time_ns())

        combined = mac + current_time

        client_id = hashlib.sha256(combined.encode()).hexdigest()
        
        return client_id

    # Returns the client ID
    def get_client_id(self):
        return self.__client_id

    # Sets the name of the user
    def set_username(self, username):
        self.__username = username

    # Returns the name of the user
    def get_username(self):
        return self.__username
    
    # Sets the old name of the user
    def set_old_username(self, old_username):
        self.__old_username = old_username

    # Returns the old name of the user
    def get_old_username(self):
        return self.__old_username
    
    # Sets whether the user is in the queue
    def set_in_queue(self, in_queue):
        self.__in_queue = in_queue

    # Returns whether the user is in the queue
    def get_in_queue(self):
        return self.__in_queue
    
    # Sets the ticket for the user
    def set_ticket(self, ticket):
        self.__ticket = ticket

    # Returns the ticket for the user
    def get_ticket(self):
        return self.__ticket
