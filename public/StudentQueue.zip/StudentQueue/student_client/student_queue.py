from PyQt6.QtGui import QStandardItemModel, QStandardItem

class StudentQueue:
    def __init__(self, list_view):
        self.__list_view = list_view

        self.__list_view_model = QStandardItemModel()
        self.__list_view.setModel(self.__list_view_model)

    def update_queue(self, queue):
        # Clear the previous items
        self.__list_view_model.clear()

        # Iterate over the queue and append each item to the list view
        for index, item in enumerate(queue, start=1):
            self.__list_view_model.appendRow(QStandardItem(f"{index}. {item['name']}"))