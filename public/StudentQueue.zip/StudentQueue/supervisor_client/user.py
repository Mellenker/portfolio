import uuid
import hashlib
import time

class User:
    def __init__(self):
        self.__client_id = self.__generate_client_id()

        self.__username = ""
        self.__joined = False
        self.__helping = False

        self.__student_helping = None
        self.__student_helping_ticket = None

    # Generates a unique client ID based on the MAC address
    def __generate_client_id(self):
        # Get the MAC address
        mac = str(uuid.getnode())

        # Get the current time in nanoseconds
        current_time = str(time.time_ns())

        combined = mac + current_time

        client_id = hashlib.sha256(combined.encode()).hexdigest()
        
        return client_id

    # Returns the client ID
    def get_client_id(self):
        return self.__client_id

    # Sets the name of the user
    def set_username(self, username):
        self.__username = username

    # Returns the name of the user
    def get_username(self):
        return self.__username
    
    # Sets whether the user has joined
    def set_joined(self, joined):
        self.__joined = joined

    # Returns whether the user has joined
    def get_joined(self):
        return self.__joined
    
    # Sets whether the user is helping a student
    def set_helping(self, helping):
        self.__helping = helping

    # Returns whether the user is helping a student
    def get_helping(self):
        return self.__helping
    
    # Sets the student the user is helping
    def set_student_helping(self, student):
        self.__student_helping = student

    # Returns the student the user is helping
    def get_student_helping(self):
        return self.__student_helping
    
    # Sets the ticket of the student the user is helping
    def set_student_helping_ticket(self, ticket):
        self.__student_helping_ticket = ticket

    # Returns the ticket of the student the user is helping
    def get_student_helping_ticket(self):
        return self.__student_helping_ticket
