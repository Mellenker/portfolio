import argparse
from gui_controller import GUIController
from user import User
from network import Network

def main(server, broad_port, req_port):
    user = User()
    network = Network(user, server, broad_port, req_port)
    
    GUIController(user, network)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--server", default="tcp://localhost", help="Server address")
    parser.add_argument("--broad_port", default="5555", help="Broadcast port")
    parser.add_argument("--req_port", default="5556", help="Request port")
    
    args = parser.parse_args()
    
    main(server=args.server, broad_port=args.broad_port, req_port=args.req_port)