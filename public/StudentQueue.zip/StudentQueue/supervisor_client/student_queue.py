from PyQt6.QtGui import QStandardItemModel, QStandardItem

class StudentQueue:
    def __init__(self, list_view):
        self.__list_view = list_view

        self.__list_view_model = QStandardItemModel()
        self.__list_view.setModel(self.__list_view_model)

    def update_queue(self, queue):
        # Clear the previous items
        self.__list_view_model.clear()

        # Iterate over the queue and append each item to the list view
        for index, item in enumerate(queue, start=1):
            self.__list_view_model.appendRow(QStandardItem(f"{index}. {item['name']}"))

    # Get the first student in the queue
    def get_first_student(self):
        try:    
            full_text = self.__list_view_model.item(0).text()

            # Remove the index prefix
            student_name = full_text.split(". ", 1)[1]

            return student_name
        except:
            return None