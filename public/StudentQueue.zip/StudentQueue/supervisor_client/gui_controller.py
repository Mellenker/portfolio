import sys
import threading

from PyQt6 import QtWidgets
from PyQt6.QtGui import QMovie
from PyQt6.QtCore import QObject, pyqtSignal

from gui import Ui_mainWindow
from student_queue import StudentQueue
from supervisor_view import SupervisorView

class GUIController(QObject):
    __spinner_signal = pyqtSignal(QtWidgets.QLabel, bool)

    def __init__(self, user, network):
        super().__init__()
        
        self.__window = None
        self.__ui = None
        self.__app = None
        
        self.__user = user
        self.__network = network

        self.__student_queue = None
        self.__supervisor_view = None

        self.__spinner = None

        self.__username_lock = threading.Lock()
        self.__start_helping_lock = threading.Lock()
        self.__stop_helping_lock = threading.Lock()

        self.__window_setup()

    # Sets up the main window
    def __window_setup(self):
        self.__app = QtWidgets.QApplication(sys.argv)

        self.__window = QtWidgets.QMainWindow()

        self.__ui = Ui_mainWindow()
        self.__ui.setupUi(self.__window)

        # Lock window resizing
        self.__window.setFixedSize(self.__window.size())

        # Set up window widgets
        self.__setup_window_widgets()

        self.__window.show()
        sys.exit(self.__app.exec())

    # Sets up the widgets for the main window
    def __setup_window_widgets(self):
        # Connect buttons
        self.__ui.joinButton.clicked.connect(self.__start_confirm_username_thread)
        self.__ui.helpStudentButton.clicked.connect(self.__start_start_helping_thread)
        self.__ui.finishHelpButton.clicked.connect(self.__start_stop_helping_thread)

        self.__student_queue = StudentQueue(self.__ui.studentListView)
        self.__supervisor_view = SupervisorView(self.__ui.supervisorListView)

        # Connect signals
        self.__network.queue_signal.connect(self.__update_queue)
        self.__network.supervisors_signal.connect(self.__update_supervisors)
        self.__spinner_signal.connect(self.__toggle_spinner)

        # Set up spinner
        self.__spinner = QMovie("../assets/spinner.gif")
        self.__spinner.start()
        self.__ui.usernameSpinnerLabel.setMovie(self.__spinner)
        self.__ui.usernameSpinnerLabel.setVisible(False)
        self.__ui.startHelpingSpinnerLabel.setMovie(self.__spinner)
        self.__ui.startHelpingSpinnerLabel.setVisible(False)
        self.__ui.stopHelpingSpinnerLabel.setMovie(self.__spinner)
        self.__ui.stopHelpingSpinnerLabel.setVisible(False)

        # Start network threads
        self.__network.start_threads()

    # Async is a headache in PyQt, so we use threading instead
    def __start_confirm_username_thread(self):
        # Try to acquire the lock without blocking
        if self.__username_lock.acquire(blocking=False):
            self.__spinner_signal.emit(self.__ui.usernameSpinnerLabel, True)
            
            thread = threading.Thread(target=self.__confirm_username)
            thread.daemon = True
            thread.start()

    # Confirms the username
    def __confirm_username(self):
        try:
            user_input = self.__ui.nameLabel.text()

            if user_input == "" or (user_input == self.__user.get_username() and self.__user.get_joined()):
                return

            self.__user.set_username(user_input)

            self.__user.set_joined(False)
            self.__user.set_helping(False)

            self.__network.join_supervisors()
        finally:
            self.__spinner_signal.emit(self.__ui.usernameSpinnerLabel, False)
            self.__username_lock.release()

    # Async is a headache in PyQt, so we use threading instead
    def __start_start_helping_thread(self):
        # Try to acquire the lock without blocking
        if self.__start_helping_lock.acquire(blocking=False):
            self.__spinner_signal.emit(self.__ui.startHelpingSpinnerLabel, True)
            
            thread = threading.Thread(target=self.__start_helping)
            thread.daemon = True
            thread.start()

    # Helps the first student in the queue
    def __start_helping(self):
        try:
            student = self.__student_queue.get_first_student()

            if student == None:
                return
            
            message = self.__ui.messageTextEdit.toPlainText()

            self.__network.help_student(student, message)
        finally:
            self.__spinner_signal.emit(self.__ui.startHelpingSpinnerLabel, False)
            self.__start_helping_lock.release()

    # Async is a headache in PyQt, so we use threading instead
    def __start_stop_helping_thread(self):
        # Try to acquire the lock without blocking
        if self.__stop_helping_lock.acquire(blocking=False):
            self.__spinner_signal.emit(self.__ui.stopHelpingSpinnerLabel, True)
            
            thread = threading.Thread(target=self.__stop_helping)
            thread.daemon = True
            thread.start()

    def __stop_helping(self):
        try:
            self.__network.finish_helping()
        finally:
            self.__spinner_signal.emit(self.__ui.stopHelpingSpinnerLabel, False)
            self.__stop_helping_lock.release()

    # Toggles the spinner
    def __toggle_spinner(self, spinnerLabel, toggle):
        spinnerLabel.setVisible(toggle)

    # Updates the student queue
    def __update_queue(self, queue):
        self.__student_queue.update_queue(queue)

    # Updates the supervisor list
    def __update_supervisors(self, supervisors):
        self.__supervisor_view.update_view(supervisors)