# README

**Melker Stafverfeldt** a22melst

**Carl Gösfeldt** c22cargo

## Important note
For the specific terminal commands listed in this document to work, ensure you have python and maven added to PATH.

## Server
**Programming language:** Java (Version 21)  
**Project management tool:** Apache Maven 3.9.9

## Student client
**Programming language:** Python (Version 3.12.3)  
**Package manager:** Pip

## Supervisor client
**Programming language:** Python (Version 3.12.3)  
**Package manager:** Pip

## Python libraries
**PyZMQ (ZMQ for Python)**

```pip install pyzmq```

**PyQt6**

```pip install PyQt6```

## Java libraries
The XML snippets was added inside the "dependencies" tag inside "pom.xml"

**JeroMQ (ZMQ for Java)**
```
<!-- https://mvnrepository.com/artifact/org.zeromq/jeromq -->
<dependency>
    <groupId>org.zeromq</groupId>
    <artifactId>jeromq</artifactId>
    <version>0.6.0</version>
</dependency>
```
**Gson**
```
<!-- https://mvnrepository.com/artifact/com.google.code.gson/gson -->
<dependency>
    <groupId>com.google.code.gson</groupId>
    <artifactId>gson</artifactId>
    <version>2.11.0</version>
</dependency>
```

## Java plugins
The XML snippet was added inside the "plugins" tag inside "pom.xml"

**Exec-maven-plugin**

```
<plugin>
    <groupId>org.codehaus.mojo</groupId>
    <artifactId>exec-maven-plugin</artifactId>
    <version>3.1.0</version>
    <configuration>
        <mainClass>assignment1.Main</mainClass>
    </configuration>
</plugin>
```
## Execution of clients
You can execute the clients by opening up a terminal in the root directory of the specific client, and running the command below. The arguments are optional.  
All arguments must not be provided. You could for example only provide an argument for server.

**Root directories for the clients**

**Student Client:** root/student_client  
**Supervisor Client:** root/supervisor_client


```
python main.py --server="ip-adress" --broad_port="port" --req_port="port"
```
**Default arguments...**  

**server:**
* Student Client: "tcp://ds.iit.his.se"  
* Supervisor Client: "tcp://localhost"  

**broad_port:** "5555"  
**req_port:** "5556"

## Execution of server
You can execute the server by opening up a terminal in the root directory of the server, and running the commands below.

This command compiles the program (only needed once).
```
mvn compile
```
This command executes the program.
```
mvn exec:java
```

**Root directory for the server**

root/server

## Tinyqueue ZMQ API + Extensions

### **Broadcast messages**

### Queue status
Topic: *queue*
```
[
    {
        "ticket": <index>,
        "name": "<name>"
    },
    
    ...
]
```
### Supervisor status
Topic: *supervisors*
```
[
    {
        "name": "<name>",
        "status": "pending"|"available"|"occupied",
        "client": undefined|{"ticket":<index>,"name":"<name>"}
    },
    
    ...
]
```
### User messages
Topic: *name of user*
```
{
    "supervisor": "<name of supervisor>",
    "message": "<message from supervisor>"
}
```
### **Request/Reply messages**

### Enter queue (Request)
```
{
    "clientId": "<unique id string>",
    "name": "<name>",
    "enterQueue": true
}
```
### Enter queue (Reply)
```
{
    "name": "<name>",
    "ticket": <index>
}
```
### Supervisor enter list (Request)

```
{
    "clientId": "<unique id string>",
    "name": "<name>",
    "enterSupervisors": true
}
```
### Supervisor enter list (Reply)
```
{
    "name": "<name>"
}
```
### Supervisor start helping (Request)
```
{
    "clientId": "<unique id string>",
    "name": "<name>",
    "message": {"recipient": "<name>", "body": "<message content>"}
}
```
### Supervisor start helping (Reply)
```
{
    "ticket": <firstInQueueTicket>
}
```
### Supervisor finish helping (Request)
```
{
    "clientId": "<unique id string>",
    "name": "<name>",
    "status": "available"
}
```
### Supervisor finish helping (Reply)
```
{}
```
### Heartbeat (Request)
```
{
    "clientId": "<unique id string>"
}
```
### Heartbeat (Reply)
```
{}
```
### Reconnect (Request)
```
{
    "clientId": "<unique id string>",
    "name": "<name>",
    "ticket": <index>,
    "reconnect": true
}
```
### Reconnect (Reply)
```
{}
```
### Error message (Reply)
```
{
    "error": "<error type>",
    "msg": "<error description>"
}
```

