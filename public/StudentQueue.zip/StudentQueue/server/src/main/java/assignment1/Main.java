package assignment1;

import java.util.Map;
import java.util.LinkedHashMap;

import java.util.Collections;

public class Main {
    
    private static int reconnectWindow = 3000; // Length of reconnection window in milliseconds
    
    public static void main(String[] args) throws Exception
    {
        Network network = new Network();

        // Add a shutdown hook to clean up resources on CTRL+C
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            network.close();
        }));
        
        StudentQueue studentQueue = new StudentQueue();
        SupervisorList supervisors = new SupervisorList();

        Map<String, Long> liveClients = Collections.synchronizedMap(new LinkedHashMap<>()); // Map of active clients

        MessageHandler msgHandler = new MessageHandler(network, studentQueue, supervisors, liveClients);

        System.out.println("Server started.");

        // Step 1: Handle reconnection messages from clients (if server just restarted)
        network.setupConnection();
        network.setSocketTimeout(reconnectWindow); // Set timeout for the socket
        System.out.println("Waiting for reconnect messages...");

        long waitTime = System.currentTimeMillis() + reconnectWindow; // Wait for reconnect messages

        while (System.currentTimeMillis() < waitTime) {
            try {
                // Receive reconnect request
                String msg = network.receiveMsg();
            
                if (msg != null)
                    msgHandler.handleReconnect(msg);
            } catch (Exception e) {
                System.out.println("Server shutting down...");
                break;
            }
        }

        // Step 2: After the reconnect window, resume normal operations
        System.out.println("Reconnect window closed. Resuming normal operations...");
        network.resetSocketTimeout(); // Reset timeout for normal operations

        // Publishes queue and supervisors continously
        BroadcastThread broadcast = new BroadcastThread(studentQueue, supervisors, network);
        broadcast.start();

        // Checks for inactive clients
        HeartbeatTracker hbTracker = new HeartbeatTracker(liveClients, studentQueue, supervisors, 4000);
        hbTracker.start();

        // Server main thread
        while (!Thread.currentThread().isInterrupted()) {
            try {
                // Receive request
                String msg = network.receiveMsg(); // This blocks until a message is received

                msgHandler.handleMessage(msg);
            } catch (Exception e) {
                System.out.println("Server shutting down...");
                break;
            }
        }
    }
}