package assignment1;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import java.util.HashMap;
import java.util.Map;

public class SupervisorList {
    
    private Map<String, Supervisor> cIDToSupervisor; // Key = clientId, Value = Supervisor
    private Map<String, Supervisor> nameToSupervisor; // Key = name, Value = Supervisor
    private Gson gson;

    public SupervisorList() {
        cIDToSupervisor = new HashMap<>();
        nameToSupervisor = new HashMap<>();
        gson = new Gson();
    }

    // Adds a supervisor to the list
    public synchronized void add(String clientId, String name, boolean isReconnect) {
        // Check if the supervisor is already in list
        if (cIDToSupervisor.containsKey(clientId)) {
            String previousName = cIDToSupervisor.get(clientId).getName();
            remove(clientId);

            System.out.println("Supervisor \"" + previousName + "\" disconnected.");
        }
            

        // Check if the name is already in list
        if (nameToSupervisor.containsKey(name))
            return;
        
        // Create a new supervisor
        Supervisor supervisor = new Supervisor(name, "available");

        // Add the supervisor to the list
        cIDToSupervisor.put(clientId, supervisor);
        nameToSupervisor.put(name, supervisor);

        if (!isReconnect)
            System.out.println("Supervisor \"" + name + "\" connected.");
        else 
            System.out.println("Supervisor \"" + name + "\" re-connected.");
    }

    // Removes a supervisor from the list
    public synchronized void remove(String clientId) {
        Supervisor supervisor = cIDToSupervisor.remove(clientId);

        if (supervisor != null)
            nameToSupervisor.remove(supervisor.getName());
    }

    // Gets the name of the supervisor by clientId
    public synchronized String getSupervisorName(String clientId) {
        Supervisor supervisor = cIDToSupervisor.get(clientId);
        
        if(supervisor == null)
            return null;

        String name = supervisor.getName();

        if (name != null)
            return name;

        return null;
    }

    // Gets the status of the supervisor by name
    public synchronized String getStatusByName(String name) {
        Supervisor supervisor = nameToSupervisor.get(name);

        return supervisor.getStatus();
    }

    // Sets the status of the supervisor by name
    public synchronized void setStatusByName(String name, String status) {
        Supervisor supervisor = nameToSupervisor.get(name);

        if (supervisor != null)
            supervisor.setStatus(status);
    }

    // Gets the student the supervisor is helping by supervisor name
    public synchronized String getHelpingAsStringByName(String name) {
        Supervisor supervisor = nameToSupervisor.get(name);
        String helpingString = gson.toJson(supervisor.getHelping());

        return helpingString;
    }

    // Supervisor starts helping a student
    public synchronized void startHelping(String name, String studentHelped, long ticket) {
        Supervisor supervisor = nameToSupervisor.get(name);

        if (supervisor == null)
            return;

        // Set the student helped by the supervisor
        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty("ticket", ticket);
        jsonObject.addProperty("name", studentHelped);

        supervisor.setHelping(jsonObject);

        System.out.println("Supervisor \"" + name + "\" started helping student \"" + studentHelped + "\".");
    }

    // Supervisor finishes helping a student
    public synchronized void clearHelping(String name) {
        Supervisor supervisor = nameToSupervisor.get(name);

        if (supervisor == null)
            return;

        // Clear the student helped by the supervisor
        supervisor.setHelping(null);
        supervisor.setStatus("available");

        System.out.println("Supervisor \"" + name + "\" finished helping.");
    }

    // Gets the list of supervisors as a JSON string
    public synchronized String getListAsJson() {
        return gson.toJson(nameToSupervisor.values());
    }

    // Check if a supervisor name exists
    public synchronized  boolean nameExists(String name) {
        return nameToSupervisor.containsKey(name);
    }
}
