package assignment1;

import java.util.Map;
import java.lang.reflect.Type;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class MessageHandler {

    private Network network;
    private StudentQueue studentQueue;
    private SupervisorList supervisors;
    private Map<String, Long> liveClients;
    private Gson gson;
    private Type messageType;

    public MessageHandler(Network network, StudentQueue studentQueue, SupervisorList supervisors, Map<String, Long> liveClients) {
        this.network = network;
        this.studentQueue = studentQueue;
        this.supervisors = supervisors;
        this.liveClients = liveClients;

        gson = new Gson();
        messageType = new TypeToken<Map<String, Object>>() {}.getType();
    }

    public void handleMessage(String msg) {

        // Parse Json
        Map<String, Object> parsedMsg = gson.fromJson(msg, messageType);

        /**** Heartbeat ****/
        if (parsedMsg.containsKey("clientId") && parsedMsg.size() == 1) {
            String clientId = parsedMsg.get("clientId").toString();

            // Check if client exists as a student or a supervisor
            if (studentQueue.getNameByID(clientId) == null && supervisors.getSupervisorName(clientId) == null) {
                liveClients.remove(clientId);
                network.replyToMsg("{}");
            } else {
                if (liveClients.containsKey(clientId))
                    liveClients.remove(clientId);

                liveClients.put(clientId, System.currentTimeMillis());

                network.replyToMsg("{}");
            }

        /**** Enter queue request ****/
        } else if (parsedMsg.containsKey("enterQueue")) {
            String clientId = parsedMsg.get("clientId").toString();
            String name = parsedMsg.get("name").toString();

            // Add student to queue
            long ticket = studentQueue.enQueue(clientId, name);

            String json = "{\"name\": \"" + name + "\", \"ticket\": " + ticket + "}";

            network.replyToMsg(json);

        /**** Supervisor connect request ****/
        } else if (parsedMsg.containsKey("enterSupervisors")) {
            String clientID = parsedMsg.get("clientId").toString();
            String name = parsedMsg.get("name").toString();

            if (supervisors.nameExists(name) == false) {
                // Supervisor name does not already exist

                // Add supervisor to list
                supervisors.add(clientID, name, false);

                String reply = "{\"name\": \"" + name + "\"}";

                network.replyToMsg(reply);
            } else {
                // Supervisor name already exists

                String error = "Supervisor name already exists";
                String errorMsg = "Supervisor name already exists";
                String json = "{\"error\": \"" + error + "\", \"msg\": \"" + errorMsg + "\"}";

                network.replyToMsg(json);
            }

        /**** Supervisor wants to start helping a student ****/
        } else if (parsedMsg.containsKey("message")) {
            String SVname = parsedMsg.get("name").toString();

            // Parse "message" part of the message
            Map<String, Object> parsedSVMsg = gson.fromJson(gson.toJson(parsedMsg.get("message")), messageType );

            String recipient = parsedSVMsg.get("recipient").toString();
            String body = parsedSVMsg.get("body").toString();

            // Get the first student in the queue
            Student firstInQueue = studentQueue.getFirstInQueue();
            String firstInQueueName = firstInQueue.getName();
            long firstInQueueTicket = firstInQueue.getTicket();
            String firstInQueueID = firstInQueue.getClientId();

            if (recipient.equals(firstInQueueName)) {
                // The student sent from the supervisor is the first in queue

                // Remove student from queue
                studentQueue.deQueue();
                liveClients.remove(firstInQueueID);

                // Update supervisor status
                supervisors.startHelping(SVname, firstInQueueName, firstInQueueTicket);
                supervisors.setStatusByName(SVname, "occupied");

                String json = "{\"supervisor\": \"" + SVname + "\", \"message\": \"" + body + "\"}";

                network.publishMsg(recipient, json);

                String jsonTicket = "{\"ticket\": \"" + firstInQueueTicket + "\"}";
                network.replyToMsg(jsonTicket);
            } else {
                // The student sent from the supervisor is not the first in queue

                String error = "Queue not updated";
                String errorMsg = "The sent student is not the first in queue";
                String json = "{\"error\": \"" + error + "\", \"msg\": \"" + errorMsg + "\"}";

                network.replyToMsg(json);
            }

        /**** Supervisor finished helping ****/
        } else if (parsedMsg.containsKey("status")) {
            String supervisorID = parsedMsg.get("clientId").toString();
            String supervisorName = supervisors.getSupervisorName(supervisorID);

            // Clear helping status for supervisor
            supervisors.clearHelping(supervisorName);

            network.replyToMsg("{}");

        /**** Invalid message ****/
        } else {
            String error = "Invalid message";
            String errorMsg = "The message did not confirm with the Tinyqueue API";
            String json = "{\"error\": \"" + error + "\", \"msg\": \"" + errorMsg + "\"}";
            
            network.replyToMsg(json);
        }
    }

    public void handleReconnect(String msg) {
        // Parse Json
        Map<String, Object> parsedMsg = gson.fromJson(msg, messageType);

        // Only allow reconnect messages
        if (parsedMsg.containsKey("reconnect")) {
            String clientId = parsedMsg.get("clientId").toString();
            String name = parsedMsg.get("name").toString();

            // Check if a ticket exists in the message
            Integer ticket = null;

            if (parsedMsg.get("ticket") != null)
                ticket = ((Double) parsedMsg.get("ticket")).intValue();

            if (ticket != null)
                // If sender is a student, re-enter student queue
                studentQueue.reEnterQueue(clientId, name, ticket);
            else {
                // If sender is a supervisor, re-enter supervisor list

                // Add supervisor to list
                supervisors.add(clientId, name, true);

                // Check if supervisor was helping a student
                if (parsedMsg.containsKey("client")) {
                    Map<String, Object> parsedClient = gson.fromJson(gson.toJson(parsedMsg.get("client")), messageType);

                    // Get client name and ticket
                    String clientName = parsedClient.get("name").toString();
                    String clientTicket = parsedClient.get("ticket").toString();

                    // Start helping the student
                    supervisors.startHelping(name, clientName, Integer.parseInt(clientTicket));
                }
            }

            // Send message to client if reconnection succeeded
            network.replyToMsg("{}");
        } else {
            // Request denied

            String error = "Request denied";
            String errorMsg = "Reconnection not accepted";
            String json = "{\"error\": \"" + error + "\", \"msg\": \"" + errorMsg + "\"}";

            network.replyToMsg(json);
        }
    }
}