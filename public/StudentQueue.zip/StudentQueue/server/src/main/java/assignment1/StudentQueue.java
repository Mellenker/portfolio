package assignment1;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.util.Map;
import java.util.HashMap;
import java.util.LinkedHashMap;

import java.util.Comparator;
import java.util.List;
import java.util.ArrayList;


public class StudentQueue {

    private Map<String, Student> cIDToStudent;  // Key = ClientId, Value = Student
    private LinkedHashMap<String, Student> queue; // Key = Name, Value = Student
    private long ticket;

    public StudentQueue() { 
        cIDToStudent = new HashMap<>();
        queue = new LinkedHashMap<>();
        ticket = 0;
    }

    // Adds a student to the queue
    public synchronized long enQueue(String clientId, String name) {
        // Check if client is already in queue
        if (cIDToStudent.containsKey(clientId)) {
            String previousName = cIDToStudent.get(clientId).getName();
            removeEntryByID(clientId); // Remove old entry

            // If the student disconnected and the name is not in the queue, print a disconnect message
            // The if-check is needed for example when: two clients are connected with the same name, and one changes username (original name should not disconnect)
            if (!queue.containsKey(previousName))
                System.out.println("Student \"" + previousName + "\" disconnected.");
        }

        // Check if name is already in queue
        if (queue.containsKey(name))
            return getTicketByName(name);

        // Create new student
        ticket++;
        Student student = new Student(clientId, name, ticket);

        // Add the student to the queue
        cIDToStudent.put(clientId, student);
        queue.put(name, student);

        System.out.println("Student \"" + name + "\" connected.");

        return ticket;
    }

    // Re-enters a student into the queue (used when a student reconnects)
    public long reEnterQueue(String clientId, String name, long ticket) {
    
        // Check if client is already in queue, if so, remove old entry
        if (cIDToStudent.containsKey(clientId))
            removeEntryByID(clientId);
    
        // Check if the name is already in the queue, if so, return existing ticket
        if (queue.containsKey(name))
            return getTicketByName(name);
    
        // Create new student
        Student student = new Student(clientId, name, ticket);
    
        // Add the student to the queue
        cIDToStudent.put(clientId, student);
        queue.put(name, student);
        
        // Sort the queue by ticket number
        sortQueueByTicket();

        System.out.println("Student \"" + name + "\" re-connected.");

        return ticket;
    }
    
    // Sorts the queue by ticket number
    private void sortQueueByTicket() {
        List<Map.Entry<String, Student>> entries = new ArrayList<>(queue.entrySet());
    
        // Sort the entries by ticket number
        entries.sort(Comparator.comparingLong(e -> e.getValue().getTicket()));
        
        // Clear the original queue
        queue.clear();
        
        // Put the sorted entries back into the queue
        for (Map.Entry<String, Student> entry : entries) {
            queue.put(entry.getKey(), entry.getValue());
        }
    }
    
    // Removes the first student in the queue
    public synchronized void deQueue() {
        if (queue.isEmpty())
            return;

        // Remove the first student in the queue
        String name = queue.keySet().iterator().next();
        Student student = queue.remove(name);

        if (student != null)
            cIDToStudent.remove(student.getClientId());

        // If queue is empty, reset ticket number
        if (queue.isEmpty())
            ticket = 0;
    }

    // Gets the first student in the queue
    public synchronized Student getFirstInQueue() {
        // If queue is empty, return null
        if (queue.isEmpty())
            return null;

        // Get the first student in the queue
        String name = queue.keySet().iterator().next();
        Student student = queue.get(name);

        if (student != null)
            return student;

        return null;
    }

    // Removes a student from the queue by their client ID
    public synchronized void removeEntryByID(String clientId) {
        Student student = cIDToStudent.get(clientId);

        if (student == null)
            return;

        // Remove student from queue
        String name = student.getName();
        cIDToStudent.remove(clientId);
        queue.remove(name);

        // If queue is empty, reset ticket number
        if (queue.isEmpty())
            ticket = 0;
    }

    // Gets the queue as a JSON string
    public synchronized String getQueueAsJson() {
        JsonArray jsonArray = new JsonArray();
        
        // Add each student in the queue to the JSON array
        for (Student student : queue.values()) {
            JsonObject studentJson = new JsonObject();
            studentJson.addProperty("ticket", student.getTicket());
            studentJson.addProperty("name", student.getName());
            
            jsonArray.add(studentJson);
        }
        
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        return gson.toJson(jsonArray);
    }

    // Gets the ticket number of a student by their name
    public synchronized long getTicketByName(String name) {
        Student student = queue.get(name);

        if (student == null)
            return -1;

        return student.getTicket();
    }

    // Gets the name of a student by their client ID
    public synchronized String getNameByID(String clientId) {
        Student student = cIDToStudent.get(clientId);

        if (student == null)
            return null;

        return student.getName();
    }
}
