package assignment1;

import org.zeromq.SocketType;
import org.zeromq.ZMQ;
import org.zeromq.ZContext;

public class Network {
    
    private ZContext context;
    private ZMQ.Socket pubSocket;
    private ZMQ.Socket repSocket;

    public Network() {
        context = new ZContext();
    }
    
    public void setupConnection() {
        // Publish socket - For broadcasting
        pubSocket = context.createSocket(SocketType.PUB);
        pubSocket.bind("tcp://*:5555");
        
        // Reply socket - For unicasting
        repSocket = context.createSocket(SocketType.REP);
        repSocket.bind("tcp://*:5556");
    }

    // Publish on PUB-socket
    public void publishMsg(String data, String json) {
        synchronized(pubSocket) {
            pubSocket.sendMore(data);
            pubSocket.send(json);
        }
    }

    // Receive on REP-socket
    public String receiveMsg() {
        synchronized(repSocket) {
            // Convert message to bytes
            byte[] bytes = repSocket.recv();

            // Check if bytes is null (which means it timed out)
            if (bytes == null)
                return null; 
            else
                return new String(bytes, ZMQ.CHARSET);  
        }
    }

    // Reply on REP-socket
    public void replyToMsg(String json) {
        synchronized(repSocket) {
            repSocket.send(json);
        }
    }

    // Set timeout on REP-socket
    public void setSocketTimeout(int timeout) {
        repSocket.setReceiveTimeOut(timeout);
    }

    // Reset REP-socket to blocking mode
    public void resetSocketTimeout() {
        repSocket.setReceiveTimeOut(-1);
    }

    // Close the sockets and the context
    public void close() {
        if (pubSocket != null)
            pubSocket.close(); // Close the socket properly

        if (repSocket != null)
            repSocket.close(); // Close the socket properly

        if (context != null)
            context.close(); // Close the ZeroMQ context
    }

}
