package assignment1;

import com.google.gson.JsonObject;

public class Supervisor {
    private String name;
    private String status;
    private JsonObject client;

    public Supervisor(String name, String status) {
        this.name = name;
        this.status = status;
        this.client = null; // The student helped by this supervisor
    }

    // Gets the name of the supervisor
    public String getName() {
        return name;
    }

    // Gets the status of the supervisor
    public String getStatus() {
        return status;
    }

    // Sets the status of the supervisor
    public void setStatus(String status) {
        this.status = status;
    }

    // Gets the student helped by the supervisor
    public JsonObject getHelping() {
        return client;
    }

    // Sets the student helped by the supervisor
    public void setHelping(JsonObject helping) {
        this.client = helping;
    }
}

