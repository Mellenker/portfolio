package assignment1;

public class BroadcastThread extends Thread {
    
    private StudentQueue studentQueue;
    private SupervisorList supervisors;
    private Network network;

    public BroadcastThread(StudentQueue studentQueue, SupervisorList supervisors, Network network) {
        this.studentQueue = studentQueue;
        this.supervisors = supervisors;
        this.network = network;
    }

    // Continously publish changes
    @Override
    public void run() {
        
        while (!Thread.currentThread().isInterrupted()) {
            // Publish student queue changes
            String queueJson = studentQueue.getQueueAsJson();
            network.publishMsg("queue", queueJson); 

            // Publish supervisor list changes
            String supervisorsJson = supervisors.getListAsJson();
            network.publishMsg("supervisors", supervisorsJson);

            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                // Handle the interruption
                Thread.currentThread().interrupt();
            }
        }
    }

}