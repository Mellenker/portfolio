package assignment1;

import java.util.Map;
import java.util.Iterator;

public class HeartbeatTracker extends Thread {

    private Map<String, Long> liveClients; // Key = ClientId, Value = Time of last received heartbeat
    private StudentQueue studentQueue;
    private SupervisorList supervisors;
    private long limit; // Count user as inactive after this many milliseconds

    public HeartbeatTracker(Map<String, Long> liveClients, StudentQueue studentQueue, SupervisorList supervisors, long limit) {
        this.liveClients = liveClients;
        this.studentQueue = studentQueue;
        this.supervisors = supervisors;
        this.limit = limit;
    }

    // Continuously remove inactive clients
    @Override
    public void run() {
        while (!Thread.currentThread().isInterrupted()) {
            long currTime = System.currentTimeMillis();
            Iterator<Map.Entry<String, Long>> iterator = liveClients.entrySet().iterator();
            
            synchronized(liveClients) {
                while (iterator.hasNext()) {

                    Map.Entry<String, Long> entry = iterator.next();

                    // Check whether limit has been crossed
                    if (entry.getValue() < currTime - limit) {
                        String clientId = entry.getKey();
                        String removedName = "Unknown";
    
                        // Check if its a student or a supervisor
                        String userType = getUserType(clientId);

                        switch(userType) {
                            case "Student":
                                removedName = studentQueue.getNameByID(clientId);
                                studentQueue.removeEntryByID(clientId);
                                break;
                            case "Supervisor":
                                removedName = supervisors.getSupervisorName(clientId);
                                supervisors.remove(clientId);
                                break;
                        }
    
                        iterator.remove();

                        System.out.println(userType + " \"" + removedName + "\" was removed for inactivity.");
    
                    }
                }
            }
            
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                // Handle the interruption
                Thread.currentThread().interrupt();
            }
        }
    }

    // Check and get user type based on clientId
    private String getUserType(String clientId) {
        String userType;

        String studentName = studentQueue.getNameByID(clientId);

        if (studentName != null) {
            userType = "Student";
            return userType;
        }

        String supervisorName = supervisors.getSupervisorName(clientId);

        if (supervisorName != null) {
            userType = "Supervisor";
            return userType;            
        }
        
        return "UserTypeError";
    }    
}
