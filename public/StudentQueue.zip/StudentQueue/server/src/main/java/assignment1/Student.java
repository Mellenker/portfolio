package assignment1;

public class Student {
    private String clientId;
    private String name;
    private long ticket;

    public Student(String clientId, String name, long ticket) {
        this.clientId = clientId;
        this.name = name;
        this.ticket = ticket;
    }

    // Returns the client ID of the student
    public String getClientId() {
        return clientId;
    }

    // Returns the name of the student
    public String getName() {
        return name;
    }

    // Returns the ticket number of the student
    public long getTicket() {
        return ticket;
    }
}

